package CPmodeling;

/**
 * @model
 */
public interface mainMemory {
 
	/**
	 * @model
	 */
	String getName();
 
}
