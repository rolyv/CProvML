package CPmodeling;

import java.util.List;

/**
 * @model
 */
public interface environment {
 
	/**
	 * @model containment="true"
	 */
	List<virtualMachine> getVMs();
	/**
	 * @model containment="true"
	 */
	List<processor> getCPUs();
	/**
	 * @model containment="true"
	 */
	List<mainMemory> getRAMs();
 
}
