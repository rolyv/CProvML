package CPmodeling;

/**
 * @model
 */
public interface processor {
 
	/**
	 * @model
	 */
	String getName();
 
}
