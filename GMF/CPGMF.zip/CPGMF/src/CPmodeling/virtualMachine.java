package CPmodeling;

import java.util.List;

/**
 * @model
 */
public interface virtualMachine {
 
	/**
	 * @model
	 */
	String getName();
 
	/**
	 * @model
	 */
	List<virtualMachine> getVMs();
 
	/**
	 * @model
	 */
	List<processor> getCPUs();
	/**
	 * @model
	 */
	List<mainMemory> getRAMs();
 
}
